
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		escrever_testemunho
	 *	@date 		Tuesday 08th of November 2022 11:02:18 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class escrever_testemunho_activity extends Activity {

	
	private View _bg__escrever_testemunho;
	private View rectangle_453;
	private TextView add_a_title___;
	private View rectangle_456;
	private View rectangle_453_ek1;
	private TextView write_your_experience___;
	private View rectangle_454;
	private View rectangle_450;
	private TextView post;
	private View rectangle_454_ek1;
	private View rectangle_450_ek1;
	private TextView public;
	private View rectangle_454_ek2;
	private View rectangle_450_ek2;
	private TextView private;
	private View ellipse_38;
	private ImageView vector;
	private ImageView vector_ek1;
	private View ellipse_38_ek1;
	private ImageView vector_ek2;
	private ImageView vector_ek3;
	private ImageView vector_ek4;
	private ImageView vector_ek5;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.escrever_testemunho);

		
		_bg__escrever_testemunho = (View) findViewById(R.id._bg__escrever_testemunho);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		add_a_title___ = (TextView) findViewById(R.id.add_a_title___);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453_ek1 = (View) findViewById(R.id.rectangle_453_ek1);
		write_your_experience___ = (TextView) findViewById(R.id.write_your_experience___);
		rectangle_454 = (View) findViewById(R.id.rectangle_454);
		rectangle_450 = (View) findViewById(R.id.rectangle_450);
		post = (TextView) findViewById(R.id.post);
		rectangle_454_ek1 = (View) findViewById(R.id.rectangle_454_ek1);
		rectangle_450_ek1 = (View) findViewById(R.id.rectangle_450_ek1);
		public = (TextView) findViewById(R.id.public);
		rectangle_454_ek2 = (View) findViewById(R.id.rectangle_454_ek2);
		rectangle_450_ek2 = (View) findViewById(R.id.rectangle_450_ek2);
		private = (TextView) findViewById(R.id.private);
		ellipse_38 = (View) findViewById(R.id.ellipse_38);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		ellipse_38_ek1 = (View) findViewById(R.id.ellipse_38_ek1);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
		vector_ek5 = (ImageView) findViewById(R.id.vector_ek5);
	
		
		//custom code goes here
	
	}
}
	
	