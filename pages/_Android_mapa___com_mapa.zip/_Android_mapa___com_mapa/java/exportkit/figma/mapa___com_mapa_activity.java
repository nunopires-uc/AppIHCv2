
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		mapa___com_mapa
	 *	@date 		Friday 02nd of December 2022 08:01:15 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class mapa___com_mapa_activity extends Activity {

	
	private View _bg__mapa___com_mapa;
	private View line_127;
	private View line_128;
	private View line_128_ek1;
	private View rectangle_456;
	private View rectangle_453;
	private ImageView vector;
	private ImageView vector_ek1;
	private View ellipse_38;
	private ImageView vector_ek2;
	private ImageView vector_ek3;
	private ImageView vector_ek4;
	private TextView search_region___;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.mapa___com_mapa);

		
		_bg__mapa___com_mapa = (View) findViewById(R.id._bg__mapa___com_mapa);
		line_127 = (View) findViewById(R.id.line_127);
		line_128 = (View) findViewById(R.id.line_128);
		line_128_ek1 = (View) findViewById(R.id.line_128_ek1);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		ellipse_38 = (View) findViewById(R.id.ellipse_38);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
		search_region___ = (TextView) findViewById(R.id.search_region___);
	
		
		//custom code goes here
	
	}
}
	
	