
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		login
	 *	@date 		Tuesday 08th of November 2022 06:39:51 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;

public class login_activity extends Activity {

	
	private View _bg__login;
	private View rectangle_454;
	private View rectangle_450;
	private View rectangle_455;
	private View rectangle_452;
	private View rectangle_456;
	private View rectangle_453;
	private TextView email;
	private TextView don_t_have_an_account__register;
	private TextView log_in;
	private TextView passenger;
	private TextView log_in_ek1;
	private TextView password;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		
		_bg__login = (View) findViewById(R.id._bg__login);
		rectangle_454 = (View) findViewById(R.id.rectangle_454);
		rectangle_450 = (View) findViewById(R.id.rectangle_450);
		rectangle_455 = (View) findViewById(R.id.rectangle_455);
		rectangle_452 = (View) findViewById(R.id.rectangle_452);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		email = (TextView) findViewById(R.id.email);
		don_t_have_an_account__register = (TextView) findViewById(R.id.don_t_have_an_account__register);
		log_in = (TextView) findViewById(R.id.log_in);
		passenger = (TextView) findViewById(R.id.passenger);
		log_in_ek1 = (TextView) findViewById(R.id.log_in_ek1);
		password = (TextView) findViewById(R.id.password);
	
		
		//custom code goes here
	
	}
}
	
	