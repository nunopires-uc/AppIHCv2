
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		lista_de_testemunhos
	 *	@date 		Thursday 17th of November 2022 06:21:01 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class lista_de_testemunhos_activity extends Activity {

	
	private View _bg__lista_de_testemunhos;
	private View ellipse_38;
	private ImageView vector;
	private ImageView vector_ek1;
	private View rectangle_456;
	private View rectangle_453;
	private TextView experience_title_1;
	private TextView lorem_ipsum_is_simply_dummy_text_of_the___;
	private ImageView vector_ek2;
	private View rectangle_456_ek1;
	private View rectangle_453_ek1;
	private TextView experience_title_2;
	private TextView lorem_ipsum_is_simply_dummy_text_of_the____ek1;
	private ImageView vector_ek3;
	private View rectangle_456_ek2;
	private View rectangle_453_ek2;
	private TextView experience_title_3;
	private TextView lorem_ipsum_is_simply_dummy_text_of_the____ek2;
	private ImageView vector_ek4;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.lista_de_testemunhos);

		
		_bg__lista_de_testemunhos = (View) findViewById(R.id._bg__lista_de_testemunhos);
		ellipse_38 = (View) findViewById(R.id.ellipse_38);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		experience_title_1 = (TextView) findViewById(R.id.experience_title_1);
		lorem_ipsum_is_simply_dummy_text_of_the___ = (TextView) findViewById(R.id.lorem_ipsum_is_simply_dummy_text_of_the___);
		vector_ek2 = (ImageView) findViewById(R.id.vector_ek2);
		rectangle_456_ek1 = (View) findViewById(R.id.rectangle_456_ek1);
		rectangle_453_ek1 = (View) findViewById(R.id.rectangle_453_ek1);
		experience_title_2 = (TextView) findViewById(R.id.experience_title_2);
		lorem_ipsum_is_simply_dummy_text_of_the____ek1 = (TextView) findViewById(R.id.lorem_ipsum_is_simply_dummy_text_of_the____ek1);
		vector_ek3 = (ImageView) findViewById(R.id.vector_ek3);
		rectangle_456_ek2 = (View) findViewById(R.id.rectangle_456_ek2);
		rectangle_453_ek2 = (View) findViewById(R.id.rectangle_453_ek2);
		experience_title_3 = (TextView) findViewById(R.id.experience_title_3);
		lorem_ipsum_is_simply_dummy_text_of_the____ek2 = (TextView) findViewById(R.id.lorem_ipsum_is_simply_dummy_text_of_the____ek2);
		vector_ek4 = (ImageView) findViewById(R.id.vector_ek4);
	
		
		//custom code goes here
	
	}
}
	
	