
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		ler_testemunho
	 *	@date 		Tuesday 08th of November 2022 11:02:30 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class ler_testemunho_activity extends Activity {

	
	private View _bg__ler_testemunho;
	private View rectangle_453;
	private TextView experience_title_example;
	private View rectangle_456;
	private View rectangle_453_ek1;
	private TextView lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry__lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_since_the_1500s__when_an_unknown_printer_took_a_galley_of_type_and_scrambled_it_to_make_a_type_specimen_book__it_has_survived_not_only_five_centuries__but_also_the_leap_into_electronic_typesetting__remaining_essentially_unchanged__it_was_popularised_in_the_1960s_with_the_release_of_letraset_sheets_containing_lorem_ipsum_passages__and_more_recently_with_desktop_publishing_software_like_aldus_pagemaker_including_versions_of_lorem_ipsum_;
	private View ellipse_38;
	private ImageView vector;
	private ImageView vector_ek1;
	private TextView author_passenger1_date_18_10_2021;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.ler_testemunho);

		
		_bg__ler_testemunho = (View) findViewById(R.id._bg__ler_testemunho);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		experience_title_example = (TextView) findViewById(R.id.experience_title_example);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453_ek1 = (View) findViewById(R.id.rectangle_453_ek1);
		lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry__lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_since_the_1500s__when_an_unknown_printer_took_a_galley_of_type_and_scrambled_it_to_make_a_type_specimen_book__it_has_survived_not_only_five_centuries__but_also_the_leap_into_electronic_typesetting__remaining_essentially_unchanged__it_was_popularised_in_the_1960s_with_the_release_of_letraset_sheets_containing_lorem_ipsum_passages__and_more_recently_with_desktop_publishing_software_like_aldus_pagemaker_including_versions_of_lorem_ipsum_ = (TextView) findViewById(R.id.lorem_ipsum_is_simply_dummy_text_of_the_printing_and_typesetting_industry__lorem_ipsum_has_been_the_industry_s_standard_dummy_text_ever_since_the_1500s__when_an_unknown_printer_took_a_galley_of_type_and_scrambled_it_to_make_a_type_specimen_book__it_has_survived_not_only_five_centuries__but_also_the_leap_into_electronic_typesetting__remaining_essentially_unchanged__it_was_popularised_in_the_1960s_with_the_release_of_letraset_sheets_containing_lorem_ipsum_passages__and_more_recently_with_desktop_publishing_software_like_aldus_pagemaker_including_versions_of_lorem_ipsum_);
		ellipse_38 = (View) findViewById(R.id.ellipse_38);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		author_passenger1_date_18_10_2021 = (TextView) findViewById(R.id.author_passenger1_date_18_10_2021);
	
		
		//custom code goes here
	
	}
}
	
	