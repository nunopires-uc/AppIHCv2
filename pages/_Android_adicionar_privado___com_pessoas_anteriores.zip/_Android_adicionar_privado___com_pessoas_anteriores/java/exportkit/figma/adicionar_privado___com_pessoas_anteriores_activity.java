
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		adicionar_privado___com_pessoas_anteriores
	 *	@date 		Thursday 17th of November 2022 06:19:42 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class adicionar_privado___com_pessoas_anteriores_activity extends Activity {

	
	private View _bg__adicionar_privado___com_pessoas_anteriores;
	private View ellipse_38;
	private ImageView vector;
	private ImageView vector_ek1;
	private View rectangle_456;
	private View rectangle_453;
	private TextView add_people_by_email___;
	private View rectangle_454;
	private View rectangle_450;
	private TextView add_to_post;
	private TextView shared_with_before;
	private TextView passenger1_email_com;
	private TextView passenger2_email_com;
	private View line_132;
	private View line_133;
	private View line_134;
	private TextView passenger3_email_com;
	private View line_135;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.adicionar_privado___com_pessoas_anteriores);

		
		_bg__adicionar_privado___com_pessoas_anteriores = (View) findViewById(R.id._bg__adicionar_privado___com_pessoas_anteriores);
		ellipse_38 = (View) findViewById(R.id.ellipse_38);
		vector = (ImageView) findViewById(R.id.vector);
		vector_ek1 = (ImageView) findViewById(R.id.vector_ek1);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		add_people_by_email___ = (TextView) findViewById(R.id.add_people_by_email___);
		rectangle_454 = (View) findViewById(R.id.rectangle_454);
		rectangle_450 = (View) findViewById(R.id.rectangle_450);
		add_to_post = (TextView) findViewById(R.id.add_to_post);
		shared_with_before = (TextView) findViewById(R.id.shared_with_before);
		passenger1_email_com = (TextView) findViewById(R.id.passenger1_email_com);
		passenger2_email_com = (TextView) findViewById(R.id.passenger2_email_com);
		line_132 = (View) findViewById(R.id.line_132);
		line_133 = (View) findViewById(R.id.line_133);
		line_134 = (View) findViewById(R.id.line_134);
		passenger3_email_com = (TextView) findViewById(R.id.passenger3_email_com);
		line_135 = (View) findViewById(R.id.line_135);
	
		
		//custom code goes here
	
	}
}
	
	