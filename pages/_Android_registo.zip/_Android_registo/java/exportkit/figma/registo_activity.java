
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		registo
	 *	@date 		Tuesday 08th of November 2022 10:59:57 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;

public class registo_activity extends Activity {

	
	private View _bg__registo;
	private View rectangle_456;
	private View rectangle_453;
	private TextView email;
	private View rectangle_456_ek1;
	private View rectangle_453_ek1;
	private TextView password;
	private TextView already_have_an_account_;
	private TextView log_in;
	private TextView register;
	private TextView passenger;
	private View rectangle_454;
	private View rectangle_450;
	private TextView register_ek1;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.registo);

		
		_bg__registo = (View) findViewById(R.id._bg__registo);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		email = (TextView) findViewById(R.id.email);
		rectangle_456_ek1 = (View) findViewById(R.id.rectangle_456_ek1);
		rectangle_453_ek1 = (View) findViewById(R.id.rectangle_453_ek1);
		password = (TextView) findViewById(R.id.password);
		already_have_an_account_ = (TextView) findViewById(R.id.already_have_an_account_);
		log_in = (TextView) findViewById(R.id.log_in);
		register = (TextView) findViewById(R.id.register);
		passenger = (TextView) findViewById(R.id.passenger);
		rectangle_454 = (View) findViewById(R.id.rectangle_454);
		rectangle_450 = (View) findViewById(R.id.rectangle_450);
		register_ek1 = (TextView) findViewById(R.id.register_ek1);
	
		
		//custom code goes here
	
	}
}
	
	