
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		landing_page
	 *	@date 		Tuesday 08th of November 2022 09:01:07 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;

public class landing_page_activity extends Activity {

	
	private View _bg__landing_page;
	private View rectangle_454;
	private View rectangle_450;
	private TextView get_started;
	private TextView passenger;
	private TextView your_travel_experience_companion;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.landing_page);

		
		_bg__landing_page = (View) findViewById(R.id._bg__landing_page);
		rectangle_454 = (View) findViewById(R.id.rectangle_454);
		rectangle_450 = (View) findViewById(R.id.rectangle_450);
		get_started = (TextView) findViewById(R.id.get_started);
		passenger = (TextView) findViewById(R.id.passenger);
		your_travel_experience_companion = (TextView) findViewById(R.id.your_travel_experience_companion);
	
		
		//custom code goes here
	
	}
}
	
	