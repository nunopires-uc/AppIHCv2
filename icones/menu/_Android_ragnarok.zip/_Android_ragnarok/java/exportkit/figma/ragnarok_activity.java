
	 
	/*
	 *	This content is generated from the API File Info.
	 *	(Alt+Shift+Ctrl+I).
	 *
	 *	@desc 		
	 *	@file 		ragnarok
	 *	@date 		Saturday 03rd of December 2022 02:55:31 PM
	 *	@title 		interface
	 *	@author 	
	 *	@keywords 	
	 *	@generator 	Export Kit v1.3.figma
	 *
	 */
	

package exportkit.figma;

import android.app.Activity;
import android.os.Bundle;


import android.view.View;
import android.widget.TextView;
import android.widget.ImageView;

public class ragnarok_activity extends Activity {

	
	private View _bg__ragnarok;
	private View rectangle_456;
	private View rectangle_453;
	private TextView experience_title_3;
	private TextView lorem_ipsum_is_simply_dummy_text_of_the___;
	private ImageView vector;

	@Override
	public void onCreate(Bundle savedInstanceState) {

		super.onCreate(savedInstanceState);
		setContentView(R.layout.ragnarok);

		
		_bg__ragnarok = (View) findViewById(R.id._bg__ragnarok);
		rectangle_456 = (View) findViewById(R.id.rectangle_456);
		rectangle_453 = (View) findViewById(R.id.rectangle_453);
		experience_title_3 = (TextView) findViewById(R.id.experience_title_3);
		lorem_ipsum_is_simply_dummy_text_of_the___ = (TextView) findViewById(R.id.lorem_ipsum_is_simply_dummy_text_of_the___);
		vector = (ImageView) findViewById(R.id.vector);
	
		
		//custom code goes here
	
	}
}
	
	