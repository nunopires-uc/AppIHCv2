package pt.uc.dei.ihc.appihc;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class LoginActivity extends AppCompatActivity {

    Button LoginButton, RegisterButton;
    EditText EditTextEmail, EditTextPassword;
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_login);

        EditTextEmail = findViewById(R.id.EditTextEmail);
        EditTextPassword = findViewById(R.id.EditTextPassword);

        EditTextEmail.setText("nuno.pires@ubi.pt");
        EditTextPassword.setText("pixarmovies");


        mAuth = FirebaseAuth.getInstance();
        LoginButton = (Button) findViewById(R.id.ButtonLogin);
        LoginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                LoginUser(EditTextEmail.getText().toString(), EditTextPassword.getText().toString());
            }
        });

        RegisterButton = (Button) findViewById(R.id.ButtonRegisterNoBG);
        RegisterButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent k = new Intent(LoginActivity.this, Register.class);
                startActivity(k);
            }
        });
    }

    private void LoginUser(String Email, String Password){
        if(TextUtils.isEmpty(Email)){
            Toast.makeText(getApplicationContext(),"Please enter an email", Toast.LENGTH_LONG).show();
            return;
        }

        if(TextUtils.isEmpty(Password)){
            Toast.makeText(getApplicationContext(),"Please define a password", Toast.LENGTH_LONG).show();
            return;
        }

        mAuth.signInWithEmailAndPassword(Email, Password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                if(task.isSuccessful()){
                    Intent k = new Intent(LoginActivity.this, MapsActivity.class);
                    startActivity(k);
                }else{
                    Toast.makeText(getApplicationContext(),"Login failed", Toast.LENGTH_LONG).show();
                }
            }
        });
    }
}