package pt.uc.dei.ihc.appihc;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.icu.text.CaseMap;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.media.Image;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;
import android.widget.ToggleButton;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.Source;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class InsertNoteActivity extends AppCompatActivity {

    private FirebaseFirestore firebaseFirestore;
    private String TAG = "InsertNoteActivity";
    private FirebaseAuth mAuth;
    private int numCity;


    EditText NoteTitle, NoteDescription;
    Button CreateNote, ReturnButton, PrivateNote;
    ImageButton LoadImage;
    boolean setPrivateNote = false;

    Double Latitude, Longitude;
    String City, Country, Address;

    FusedLocationProviderClient fusedLocationProviderClient;
    public static final int REQUEST_CODE = 100;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        this.getWindow().setFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN, WindowManager.LayoutParams.FLAG_FULLSCREEN);
        getSupportActionBar().hide();
        setContentView(R.layout.activity_insert_note);

        mAuth = FirebaseAuth.getInstance();

        LoadImage = (ImageButton)findViewById(R.id.LoadImage);
        LoadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UploadImage();
            }
        });

        /*ReturnButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                finish();
            }
        });*/


        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);



        firebaseFirestore = FirebaseFirestore.getInstance();

        NoteTitle = (EditText) findViewById(R.id.NoteTitle);
        NoteDescription = (EditText) findViewById(R.id.NoteDescription);
        LoadImage = (ImageButton) findViewById(R.id.LoadImage);
        PrivateNote = (Button) findViewById(R.id.PrivateNote);
        CreateNote = (Button) findViewById(R.id.CreateNote);


        PrivateNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //Abrir
            }
        });



        /*
        PrivateNote.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    setPrivateNote = true;
                } else {
                    // The toggle is disabled
                }
            }
        });*/


        CreateNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                //InsertNote();
                //FindLocation();

                Bundle extras = getIntent().getExtras();
                if (extras != null) {
                    Latitude = extras.getDouble("Latitude");
                    Longitude = extras.getDouble("Longitude");
                    City = extras.getString("City");
                    Country = extras.getString("Country");
                    Address = extras.getString("Address");

                    //The key argument here must match that used in the other activity

                    Log.i("$#Latitude:", String.valueOf(Latitude));
                    Log.i("$#Longitude:", String.valueOf(Longitude));
                    Log.i("$#City:", City);
                    Log.i("$#Country:", Country);
                    Log.i("$#Address", Address);

                    InsertNote(Country, City, Address,Latitude, Longitude);

                }

            }
        });

        LoadImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Snackbar.make(view, "Here's a Snackbar", Snackbar.LENGTH_LONG)
                        .setAction("Action", null).show();
            }
        });
    }

    public void UploadImage(){
        Intent intent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        intent.setType("image/*");
        launcher.launch(intent);

        //startActivityForResult();
    }

    private final ActivityResultLauncher<Intent> launcher = registerForActivityResult(new ActivityResultContracts.StartActivityForResult(),
            result -> {
                if(result.getResultCode() == Activity.RESULT_OK && result.getData() != null){
                    Uri phtoUri = result.getData().getData();
                }
            });

    private void FindLocation(){
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED){
            fusedLocationProviderClient.getLastLocation().addOnSuccessListener(new OnSuccessListener<Location>() {
                @Override
                public void onSuccess(Location location) {
                    if(location != null){
                        List<Address> addressList = null;
                        Geocoder geocoder = new Geocoder(InsertNoteActivity.this, Locale.getDefault());
                        try {
                            addressList = geocoder.getFromLocation(location.getLatitude(), location.getLongitude(), 1);
                        } catch (IOException e) {
                            e.printStackTrace();
                        }
                        Log.i("$#Latitude", String.valueOf(addressList.get(0).getLatitude()));
                        Log.i("$#Longitude", String.valueOf(addressList.get(0).getLongitude()));
                        Log.i("$#City", String.valueOf(addressList.get(0).getLocality()));
                        Log.i("$#Country", String.valueOf(addressList.get(0).getCountryName()));

                    }
                }
            });
        }else{
            AskForPermission();
        }
    }

    private void AskForPermission(){
        ActivityCompat.requestPermissions(InsertNoteActivity.this, new String[]{
               Manifest.permission.ACCESS_FINE_LOCATION
        }, REQUEST_CODE);
    }


    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == REQUEST_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                FindLocation();
            }else{
                Toast.makeText(InsertNoteActivity.this, "Permission Required", Toast.LENGTH_SHORT).show();
            }
        }
    }

    private void InsertNote(String Country, String City, String Address, Double Latitude, Double Longitude){
        /*
        Title:
        Description:
        Image: https://cdn-icons-png.flaticon.com/512/5110/5110429.png
        Author:
        City:
        Address:
        Country:
        Latitude:
        Longitude:
        isPrivate;
         */


        Map<String, Object> NewNote = new HashMap<>();
        ArrayList<String> PrivateContacts = new ArrayList<>();

        if((!NoteTitle.getText().toString().isEmpty()) && (!NoteDescription.getText().toString().isEmpty())){
            NewNote.put("Title", NoteTitle.getText().toString());
            NewNote.put("Description", NoteDescription.getText().toString());
            NewNote.put("Author", FirebaseAuth.getInstance().getCurrentUser().getUid().toString());
            NewNote.put("Country", Country);
            NewNote.put("City", City);
            NewNote.put("Address", Address);
            NewNote.put("ImageUrl", "https://cdn-icons-png.flaticon.com/512/5110/5110429.png");
            NewNote.put("Latitude", Latitude);
            NewNote.put("Longitude", Longitude);
            NewNote.put("isPrivate",  setPrivateNote);
            NewNote.put("contacts", PrivateContacts);


            FirebaseFirestore db = FirebaseFirestore.getInstance();
            db.collection("notes").add(NewNote).addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                @Override
                public void onSuccess(DocumentReference documentReference) {
                    Log.d(TAG, "DocumentSnapshot added with ID: " + documentReference.getId());
                    Toast.makeText(InsertNoteActivity.this, "Testemony added successfully.", Toast.LENGTH_SHORT).show();
                    //Return to .Maps Activity
                    /*Intent intent = new Intent();
                    intent.putExtra("newMarker", "1");
                    setResult(RESULT_OK, intent);
                    finish();*/
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Log.w(TAG, "Error adding Note", e);
                }
            });


            firebaseFirestore.collection("cityData").document(City).get().addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                @Override
                public void onComplete(@NonNull Task<DocumentSnapshot> task) {
                    if(task.isSuccessful()){
                        DocumentSnapshot doc = task.getResult();
                        if(doc.exists()){
                            numCity = (int) doc.get("total");
                        }else{
                            numCity = 1;
                        }
                    }
                }
            });

            firebaseFirestore.collection("cityData")
                    .document(City)
                    .update("total", numCity+1)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void unused) {
                            Toast.makeText(InsertNoteActivity.this, "Testemony added successfully.", Toast.LENGTH_SHORT).show();
                        }
                    });
        }else{
            NoteTitle.setError("Please write a title.");
            NoteDescription.setError("The item Description cannot be empty.");
        }
    }
}