package pt.uc.dei.ihc.appihc;

public class DefaultNoteAdapter {

}
