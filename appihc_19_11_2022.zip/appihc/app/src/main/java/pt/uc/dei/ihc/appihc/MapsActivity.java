package pt.uc.dei.ihc.appihc;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.FragmentActivity;
import android.Manifest;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.drawable.Drawable;
import android.location.Address;
import android.location.Geocoder;
import android.location.Location;
import android.location.LocationRequest;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;
import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.internal.ICameraUpdateFactoryDelegate;
import com.google.android.gms.maps.model.BitmapDescriptor;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.android.material.navigation.NavigationBarView;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import pt.uc.dei.ihc.appihc.databinding.ActivityMainBinding;
import pt.uc.dei.ihc.appihc.databinding.ActivityMapsBinding;

public class MapsActivity extends FragmentActivity implements OnMapReadyCallback {


    //https://www.c-sharpcorner.com/article/getting-location-address-from-latitude-and-longitude-using-google-maps-geocoding/

    private GoogleMap mMap;
    ArrayList<LatLng> markers = new ArrayList<LatLng>();
    ArrayList<String> titles = new ArrayList<String>();
    private ActivityMapsBinding binding;
    private FirebaseFirestore db;
    Location currentLocation;
    FusedLocationProviderClient fusedLocationProviderClient;
    private static final int REQUEST_CODE = 101;
    BottomNavigationView bottomNavigationView;
    FloatingActionButton CreateNote;

    Double Latitude, Longitude;
    String City, Country, Address, CurrentCity;
    Byte IntentResult = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        binding = ActivityMapsBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        CreateNote = findViewById(R.id.fab);
        bottomNavigationView = findViewById(R.id.bottom_navigation);
        bottomNavigationView.setSelectedItemId(R.id.home);

        db = FirebaseFirestore.getInstance();

        //db.collection("notes").whereEqualTo("City", City)

        db.collection("notes")
                .get()
                .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                    @Override
                    public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                        // after getting the data we are calling on success method
                        // and inside this method we are checking if the received
                        // query snapshot is empty or not.
                        if (!queryDocumentSnapshots.isEmpty()) {
                            // if the snapshot is not empty we are
                            // hiding our progress bar and adding
                            // our data in a list.
                            //loadingPB.setVisibility(View.GONE);
                            List<DocumentSnapshot> list = queryDocumentSnapshots.getDocuments();
                            for (DocumentSnapshot d : list) {

                                LatLng sydney = new LatLng((Double) d.get("Latitude"), (Double) d.get("Longitude"));

                                //LatLng UserPosition = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());
                                String title = (String) d.get("Title");
                                mMap.addMarker(new MarkerOptions().position(sydney).title((String) title)
                                        .icon(BitmapFromVector(getApplicationContext(), R.drawable.testemunho_icone)));
                                markers.add(sydney);
                                titles.add(title);


                                // after getting this list we are passing
                                // that list to our object class.
                                //Courses c = d.toObject(Courses.class);

                                // and we will pass this object class
                                // inside our arraylist which we have
                                // created for recycler view.
                                //coursesArrayList.add(c);
                            }
                            // after adding the data to recycler view.
                            // we are calling recycler view notifuDataSetChanged
                            // method to notify that data has been changed in recycler view.
                            //courseRVAdapter.notifyDataSetChanged();
                        } else {
                            // if the snapshot is empty we are displaying a toast message.
                            Toast.makeText(MapsActivity.this, "No data found in Database", Toast.LENGTH_SHORT).show();
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // if we do not get any data or any error we are displaying
                        // a toast message that we do not get any data
                        Toast.makeText(MapsActivity.this, "Fail to get the data.", Toast.LENGTH_SHORT).show();
                    }
                });


        //CurrentCity = City;
        //Log.i("#$CC", CurrentCity);

        /*
        if(!CurrentCity.equals(City)){

            //Utilizador mudou de cidade
            CurrentCity = City;
        }*/







        bottomNavigationView.setOnItemSelectedListener(new NavigationBarView.OnItemSelectedListener() {
            @Override
            public boolean onNavigationItemSelected(@NonNull MenuItem item) {
                switch (item.getItemId()) {
                    case R.id.home:
                        return true;


                    case R.id.profile:
                        startActivity(new Intent(getApplicationContext(), NavigationActivity.class));
                        overridePendingTransition(0, 0);
                        return true;

                    case R.id.notification:
                        break;
                }
                return false;
            }
        });

        CreateNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(MapsActivity.this, InsertNoteActivity.class);
                i.putExtra("Latitude", Latitude);
                i.putExtra("Longitude", Longitude);
                i.putExtra("City", City);
                i.putExtra("Country", Country);
                i.putExtra("Address", Address);
                startActivity(i);
            }
        });




        fusedLocationProviderClient = LocationServices.getFusedLocationProviderClient(this);


        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        /*
        for(int i = 0; i < markers.size(); i++){
            for(int j = 0; j < titles.size(); j++){
                mMap.addMarker(new MarkerOptions().position(markers.get(i)).title(String.valueOf(titles.get(j))));
            }
        }
         */

        mMap.setOnMarkerClickListener(new GoogleMap.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(@NonNull Marker marker) {
                Intent k = new Intent(MapsActivity.this, ReadNote.class);
                k.putExtra("Title", marker.getTitle().toString());
                startActivity(k);
                return false;
            }
        });

        /*
        */



        //mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
        //mMap.setOnMapLongClickListener((GoogleMap.OnMapLongClickListener) this);
        //mMap.setOnMarkerDragListener((GoogleMap.OnMarkerDragListener) this);

        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) ==
                PackageManager.PERMISSION_GRANTED) {
            enableUserLocation();
            zoomToUserLocation();










        } else {
            if (ActivityCompat.shouldShowRequestPermissionRationale(this, Manifest.permission.ACCESS_FINE_LOCATION)) {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            } else {
                ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            }
        }

        // Add a marker in Sydney and move the camera
        LatLng sydney = new LatLng(-34, 151);

        //LatLng UserPosition = new LatLng(currentLocation.getLatitude(), currentLocation.getLongitude());

        mMap.addMarker(new MarkerOptions().position(sydney).title("user Position"));

        //Bitmap bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.letter_background);
        mMap.addMarker(new MarkerOptions().position(sydney).title("Marker in Sydney")
                .snippet("Lorem ipslum hello hello").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));


        //.
        //
        mMap.moveCamera(CameraUpdateFactory.newLatLng(sydney));
    }


    private void enableUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        mMap.setMyLocationEnabled(true);
    }

    private void zoomToUserLocation() {
        if (ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            // TODO: Consider calling
            //    ActivityCompat#requestPermissions
            // here to request the missing permissions, and then overriding
            //   public void onRequestPermissionsResult(int requestCode, String[] permissions,
            //                                          int[] grantResults)
            // to handle the case where the user grants the permission. See the documentation
            // for ActivityCompat#requestPermissions for more details.
            return;
        }
        Task<Location> locationTask = fusedLocationProviderClient.getLastLocation();
        locationTask.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                LatLng latLng = new LatLng(location.getLatitude(), location.getLongitude());

                Latitude = latLng.latitude;
                Longitude = latLng.longitude;

                Geocoder geocoder = new Geocoder(MapsActivity.this, Locale.getDefault());
                try {
                    List<Address> addressList = geocoder.getFromLocation(Latitude, Longitude, 1);
                    Log.i("$#Latitude", String.valueOf(addressList.get(0).getLatitude()));
                    Log.i("$#Longitude", String.valueOf(addressList.get(0).getLongitude()));
                    Log.i("$#City", String.valueOf(addressList.get(0).getLocality()));
                    City = String.valueOf(addressList.get(0).getLocality());
                    Log.i("$#Country", String.valueOf(addressList.get(0).getCountryName()));
                    Country = String.valueOf(addressList.get(0).getCountryName());
                    Log.i("$#AddressLine", String.valueOf(addressList.get(0).getAddressLine(0)));
                    Address = String.valueOf(addressList.get(0).getAddressLine(0));
                } catch (IOException e) {
                    e.printStackTrace();
                }

                if(IntentResult == 1){
                    mMap.addMarker(new MarkerOptions().position(latLng).title("Hello")
                            .snippet("User Created this").icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_AZURE)));
                    IntentResult = 0;
                }

                /*
                Log.i("UserPosition:", latLng.toString());


                 */
                mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(latLng, 20));
            }
        });
    }

    private void getCurrentLocation(){

        //LocationRequest mLocationRequest = LocationRequest.create();
        if(ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED
                && ActivityCompat.checkSelfPermission(this, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED){

            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, REQUEST_CODE);
            return;
        }

        Task<Location> task = fusedLocationProviderClient.getLastLocation();
        task.addOnSuccessListener(new OnSuccessListener<Location>() {
            @Override
            public void onSuccess(Location location) {
                if(location != null){
                    currentLocation = location;
                    Toast.makeText(getApplicationContext(), (int) currentLocation.getLatitude(), Toast.LENGTH_LONG).show();
                    SupportMapFragment supportMapFragment = (SupportMapFragment) getSupportFragmentManager().findFragmentById(R.id.map);
                    assert supportMapFragment != null;
                    supportMapFragment.getMapAsync(MapsActivity.this);
                }
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == REQUEST_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                enableUserLocation();
                zoomToUserLocation();
            }else{
               //
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private BitmapDescriptor BitmapFromVector(Context context, int vectorResId) {
        // below line is use to generate a drawable.
        Drawable vectorDrawable = ContextCompat.getDrawable(context, vectorResId);

        // below line is use to set bounds to our vector drawable.
        vectorDrawable.setBounds(0, 0, vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight());

        // below line is use to create a bitmap for our
        // drawable which we have added.
        Bitmap bitmap = Bitmap.createBitmap(vectorDrawable.getIntrinsicWidth(), vectorDrawable.getIntrinsicHeight(), Bitmap.Config.ARGB_8888);

        // below line is use to add bitmap in our canvas.
        Canvas canvas = new Canvas(bitmap);

        // below line is use to draw our
        // vector drawable in canvas.
        vectorDrawable.draw(canvas);

        // after generating our bitmap we are returning our bitmap.
        return BitmapDescriptorFactory.fromBitmap(bitmap);
    }

    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == 1) {
            if(resultCode == RESULT_OK) {
                String addMarkerResult = data.getStringExtra("newMarker");
                if(addMarkerResult.equals("1")){
                    IntentResult = 1;
                    Log.i("$#", "Here");
                }
            }
        }
    }


}